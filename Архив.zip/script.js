// let guestList = "Shorux Alex Jimmy Baxa".toLowerCase()

// let guest = prompt("What is your name ?")

// if (guestList.includes(guest.toLowerCase().trim())) {   
//     alert("Welcome mr/ms " + guest)
// } else {
//     alert("Sorry mr/ms " + guest)
// }

/* Sample */

// let assd = alert("Welcome to the restaurant !")

// let restaurant = "Shorux Farzod Samir Abdi Axmed Hasan/Husen".toLowerCase()
// let restau = prompt("What can i call you ?")

// if (restaurant.includes(restau.toLowerCase().trim())) {
//     alert("Welcome my man")
// } else {
//     alert("Fuck off")
// }



// let arr = ['samir', 'abdi', 'farzod', 'mamajani']

// // // arr.push('jesko', 'venom')  // end
// // arr.unshift('laziz', 'parviz')  // start

// // arr.pop()  // delete last
// // arr.shift()  // delete first

// // arr.splice(2,1, 'anton' )  // index,amount, replace
// /*  OR */
// // arr.splice(arr.indexOf('abdi'),1,)

// console.log(arr);



// let arr = ['amir', 'samir', 'farzod', 'farux', 'shoxa']
// let num = prompt('any number')
// if (num >= 0 && num < arr.length) {
//     arr.splice(num, 1)
// } else {
//     alert('ERROR')
// }
// console.log(arr);



// let arr = ['damir', 'samir', 'farzod', 'shoxrux']

// let num = +prompt('number')

// switch (num) {
    //     case 0:
    //         alert(arr[0])
    //         break;
    //     case 1:
    //         alert(arr[1])
    //         break;
    //     case 2:
    //         alert(arr[2])
    //         break;
    //     case 3:
    //         alert(arr[3])
    //         break;
    
    //     default:
    //         alert("error")
    //         break;
    // }
    
    let arr = ['damir', 'samir' ,'farzod' ,'shoxruh']
    let name = prompt('name')
    
    if (arr = arr.filter(item => item !== name)) {
        alert('имя было удалено')
    } else {
        alert('error')
    }
    console.log(arr);